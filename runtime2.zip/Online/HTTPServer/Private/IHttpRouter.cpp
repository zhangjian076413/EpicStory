// Copyright Epic Games, Inc. All Rights Reserved.

#include "IHttpRouter.h"

IHttpRouter::~IHttpRouter()
{
}

