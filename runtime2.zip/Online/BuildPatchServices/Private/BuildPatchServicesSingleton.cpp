// Copyright Epic Games, Inc. All Rights Reserved.

#include "BuildPatchServicesSingleton.h"

FName FBuildPatchServices::ModuleName = TEXT("BuildPatchServices");
BuildPatchServices::FBuildPatchServicesInitSettings FBuildPatchServices::InitSettings;
