// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "GenericPlatform/GenericPlatformBackgroundHttp.h"

//Currently no implementation on Unix
typedef FGenericPlatformBackgroundHttp FPlatformBackgroundHttp;