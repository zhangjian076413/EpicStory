// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "GenericPlatform/GenericPlatformBackgroundHttp.h"

//Currently no implementation on Mac
typedef FGenericPlatformBackgroundHttp FPlatformBackgroundHttp;