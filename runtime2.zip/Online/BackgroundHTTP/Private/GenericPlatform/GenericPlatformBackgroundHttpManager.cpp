// Copyright Epic Games, Inc. All Rights Reserved.

#include "GenericPlatform/GenericPlatformBackgroundHttpManager.h"

FGenericPlatformBackgroundHttpManager::~FGenericPlatformBackgroundHttpManager()
{
}