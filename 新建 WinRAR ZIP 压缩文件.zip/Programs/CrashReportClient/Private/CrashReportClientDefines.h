// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#ifndef CRASH_REPORT_WITH_RECOVERY
#define CRASH_REPORT_WITH_RECOVERY 0
#endif

#ifndef CRASH_REPORT_WITH_MTBF
#define CRASH_REPORT_WITH_MTBF 0
#endif
