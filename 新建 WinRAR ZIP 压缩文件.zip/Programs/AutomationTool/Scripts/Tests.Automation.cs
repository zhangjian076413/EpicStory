// Copyright Epic Games, Inc. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security;
using System.Security.Principal;
using System.Security.Permissions;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;
using Microsoft.Win32.SafeHandles;
using AutomationTool;
using System.Threading;
using UnrealBuildTool;

[Help("Tests P4 functionality. Runs 'p4 info'.")]
[RequireP4]
[DoesNotNeedP4CL]
class TestP4_Info : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("P4CLIENT={0}", GetEnvVar("P4CLIENT"));
		LogInformation("P4PORT={0}", GetEnvVar("P4PORT"));

		var Result = P4.P4("info");
		if (Result.ExitCode != 0)
		{
			throw new AutomationException("p4 info failed: {0}", Result.Output);
		}
	}
}

[Help("GitPullRequest")]
[Help("Dir=", "Directory of the Git repo.")]
[Help("PR=", "PR # to shelve, can use a range PR=5-25")]
[RequireP4]
[DoesNotNeedP4CL]
class GitPullRequest : BuildCommand
{
	/// URL to our UnrealEngine repository on GitHub
	static readonly string GitRepositoryURL_Engine = "https://github.com/EpicGames/UnrealEngine.git";
	static readonly string GitRepositoryURL_UT = "https://github.com/EpicGames/UnrealTournament.git";
	string GitRepositoryURL = null;

	bool bDoingUT = false;

	string FindExeFromPath(string ExeName, string ExpectedPathSubstring = null)
	{
		if (File.Exists(ExeName))
		{
			return Path.GetFullPath(ExeName);
		}

		foreach (string BasePath in Environment.GetEnvironmentVariable("PATH").Split(Path.PathSeparator))
		{
			var FullPath = Path.Combine(BasePath, ExeName);
			if (ExpectedPathSubstring == null || FullPath.IndexOf(ExpectedPathSubstring, StringComparison.InvariantCultureIgnoreCase) != -1)
			{
				if (File.Exists(FullPath))
				{
					return FullPath;
				}
			}
		}

		return null;
	}
	string RunGit(string GitCommandLine)
	{
		string GitExePath = FindExeFromPath("Git.exe", "PortableGit");
		if (GitExePath == null)
		{
			throw new AutomationException("Unable to find Git.exe in the system path under a 'PortableGit' subdirectory.  Make sure the GitHub client is installed, and you are running this script from within a GitHub Command Shell.  We want to make sure we're using the correct version of Git, in case multiple versions are on the computer, which is why we check for a PortableGit folder that the GitHub Shell uses.");
		}

		LogInformation("Running {0} {1}", GitExePath, GitCommandLine);

		IProcessResult Result = Run(App: GitExePath, CommandLine: GitCommandLine, Options: (ERunOptions.NoLoggingOfRunCommand | ERunOptions.AllowSpew | ERunOptions.AppMustExist));
		if (Result.ExitCode != 0)
		{
			throw new AutomationException(String.Format("Command failed (Result:{2}): {0} {1}", GitExePath, GitCommandLine, Result.ExitCode));
		}

		// Return the results (sans leading and trailing whitespace)
		return Result.Output.Trim();
	}

	bool ScanForBranchAndCL_BaseVersion(string GitCommand, out string Depot, out int CL)
	{
		Depot = null;
		CL = 0;
		try
		{
			var Base = RunGit(GitCommand);

			string BaseStart = "Engine source (";
			string BaseEnd = ")";

			if (Base.Contains(BaseStart) && Base.Contains(BaseEnd))
			{
				Base = Base.Substring(Base.IndexOf(BaseStart) + BaseStart.Length);
				if (Base.StartsWith("4."))
				{
					Depot = "//depot/UE4-Releases/4." + Base.Substring(2, 1);
				}
				else if (Base.StartsWith("Main"))
				{
					Depot = "//depot/UE4";
				}
				else if (Base.StartsWith("UT"))
				{
					Depot = "//depot/UE4-UT";
				}
				else
				{
					throw new AutomationException("Unrecognized branch.");
				}
				LogInformation("Depot {0}", Depot);

				Base = Base.Substring(0, Base.IndexOf(BaseEnd));
				if (!Base.Contains(" "))
				{
					throw new AutomationException("Unrecognized commit3.");
				}
				Base = Base.Substring(Base.LastIndexOf(" "));
				LogInformation("CL String {0}", Base);
				CL = int.Parse(Base);
			}
			LogInformation("CL int {0}", CL);
			if (CL < 2000000 || String.IsNullOrWhiteSpace(Depot))
			{
				throw new AutomationException("Unrecognized commit3.");
			}

			return true;
		}
		catch (Exception)
		{
			CL = 0;
			return false;
		}
	}

	bool ScanForBranchAndCL_LiveVersion(string GitCommand, out string Depot, out int CL)
	{
		Depot = null;
		CL = 0;
		try
		{
			var Base = RunGit(GitCommand);

			string LiveStart = "[CL ";
			string LiveEnd = " branch]";

			if (Base.Contains(LiveStart) && Base.Contains(LiveEnd))
			{
				var CLStuff = Base.Substring(Base.IndexOf(LiveStart) + LiveStart.Length);
				if (CLStuff.IndexOf(" ") <= 0)
				{
					throw new AutomationException("Unrecognized commit5.");
				}
				CLStuff = CLStuff.Substring(0, CLStuff.IndexOf(" "));
				LogInformation("CL String {0}", CLStuff);
				CL = int.Parse(CLStuff);

				var BranchStuff = Base.Substring(Base.IndexOf(LiveStart) + LiveStart.Length, Base.IndexOf(LiveEnd) - Base.IndexOf(LiveStart) - LiveStart.Length);
				if (BranchStuff.IndexOf(" ") <= 0)
				{
					throw new AutomationException("Unrecognized commit6.");
				}
				BranchStuff = BranchStuff.Substring(BranchStuff.LastIndexOf(" ") + 1);
				LogInformation("Branch String {0}", BranchStuff);
				if (BranchStuff.StartsWith("4."))
				{
					Depot = "//depot/UE4-Releases/4." + BranchStuff.Substring(2, 1);
				}
				else if (BranchStuff.StartsWith("Main"))
				{
					Depot = "//depot/UE4";
				}
				else if (BranchStuff.StartsWith("UT"))
				{
					Depot = "//depot/UE4-UT";
				}
				else
				{
					throw new AutomationException("Unrecognized branch2.");
				}
			}
			LogInformation("CL int {0}", CL);
			if (CL < 2000000 || String.IsNullOrWhiteSpace(Depot))
			{
				throw new AutomationException("Unrecognized commit3.");
			}

			return true;
		}
		catch (Exception)
		{
			CL = 0;
			return false;
		}
	}

	void ExecuteInner(string Dir, int PR)
	{
		string PRNum = PR.ToString();

		// Discard any old changes we may have committed
		RunGit("reset --hard");

		// show-ref is just a double check that the PR exists
		//var Refs = RunGit("show-ref");
		/*if (!Refs.Contains("refs/remotes/origin/pr/" + PRNum))
		{
			throw new AutomationException("This is not among the refs: refs/remotes/origin/pr/{0}", PRNum);
		}*/
		RunGit(String.Format("fetch origin refs/pull/{0}/head:pr/{1}", PRNum, PRNum));
		RunGit(String.Format("checkout pr/{0} --", PRNum));

		int CLBase;
		string DepotBase;
		ScanForBranchAndCL_BaseVersion(String.Format("log --author=TimSweeney --author=UnrealBot -100 pr/{0} --", PRNum), out DepotBase, out CLBase);


		int CLLive;
		string DepotLive;
		ScanForBranchAndCL_LiveVersion(String.Format("log -100 pr/{0} --", PRNum), out DepotLive, out CLLive);

		if (CLLive == 0 && CLBase == 0)
		{
			throw new AutomationException("Could not find a base change and branch using either method.");
		}

		int CL = 0;
		string Depot = "";

		if (CLBase > CLLive)
		{
			CL = CLBase;
			Depot = DepotBase;
		}
		else
		{
			CL = CLLive;
			Depot = DepotLive;
		}
		if (CL < 2000000 || String.IsNullOrWhiteSpace(Depot))
		{
			throw new AutomationException("Could not find a base change and branch using either method.");
		}


		P4ClientInfo NewClient = P4.GetClientInfo(P4Env.Client);

		foreach (var p in NewClient.View)
		{
			LogInformation("{0} = {1}", p.Key, p.Value);
		}

		string TestClient = P4Env.User + "_" + Environment.MachineName + "_PullRequests_" + Depot.Replace("/", "_");
		NewClient.Owner = P4Env.User;
		NewClient.Host = Environment.MachineName;
		NewClient.RootPath = Dir;
		NewClient.Name = TestClient;
		NewClient.View = new List<KeyValuePair<string, string>>();
		NewClient.View.Add(new KeyValuePair<string, string>(Depot + "/...", "/..."));
		NewClient.Stream = null;
		if (!P4.DoesClientExist(TestClient))
		{
			P4.CreateClient(NewClient);
		}

		var P4Sub = new P4Connection(P4Env.User, TestClient, P4Env.ServerAndPort);

		P4Sub.Sync(String.Format("-f -k -q {0}/...@{1}", Depot, CL));

		var Change = P4Sub.CreateChange(null, String.Format("GitHub pull request #{0}", PRNum));
		P4Sub.ReconcileNoDeletes(Change, CommandUtils.MakePathSafeToUseWithCommandLine(CombinePaths(Dir, bDoingUT ? "UnrealTournament" : "Engine", "...")));
		P4Sub.Shelve(Change);
		P4Sub.Revert(Change, "-k //...");
	}

	public override void ExecuteBuild()
	{
		if (ParseParam("UT"))
		{
			bDoingUT = true;
			GitRepositoryURL = GitRepositoryURL_UT;
		}
		else
		{
			bDoingUT = false;
			GitRepositoryURL = GitRepositoryURL_Engine;
		}
		var Dir = ParseParamValue("Dir");
		if (String.IsNullOrEmpty(Dir))
		{
			// No Git repo directory was specified, so we'll choose a directory automatically
			Dir = Path.GetFullPath(Path.Combine(CmdEnv.LocalRoot, "Engine", "Intermediate", bDoingUT ? "PullRequestGitRepo_UT" : "PullRequestGitRepo"));
		}

		var PRNum = ParseParamValue("PR");
		if (String.IsNullOrEmpty(PRNum))
		{
			throw new AutomationException("Must Provide PR arg, the number of the PR, or a range.");
		}
		int PRMin;
		int PRMax;

		if (PRNum.Contains("-"))
		{
			var Nums = PRNum.Split("-".ToCharArray());
			PRMin = int.Parse(Nums[0]);
			PRMax = int.Parse(Nums[1]);
		}
		else
		{
			PRMin = int.Parse(PRNum);
			PRMax = PRMin;
		}
		var Failures = new List<string>();


		// Setup Git repo
		{
			if (ParseParam("Clean"))
			{
				Console.WriteLine("Cleaning temporary Git repository folder... ");

				// Wipe the Git repo directory
				if (!InternalUtils.SafeDeleteDirectory(Dir))
				{
					throw new AutomationException("Unable to clean out temporary Git repo directory: " + Dir);
				}
			}

			// Change directory to the Git repository
			bool bRepoAlreadyExists = InternalUtils.SafeDirectoryExists(Dir);
			if (!bRepoAlreadyExists)
			{
				InternalUtils.SafeCreateDirectory(Dir);
			}
			PushDir(Dir);

			if (!bRepoAlreadyExists)
			{
				// Don't init Git if we didn't clean, because the old repo is probably still there.

				// Create the Git repository
				RunGit("init");
			}

			// Make sure that creating the repository worked OK
			RunGit("status");

			// Check to see if we already have a remote origin setup
			{
				string Result = RunGit("remote -v");
				if (Result == "origin")
				{
					// OK, we already have an origin but no remote is associated with it.  We'll do that now.
					RunGit("remote set-url origin " + GitRepositoryURL);
				}
				else if (Result.IndexOf(GitRepositoryURL, StringComparison.InvariantCultureIgnoreCase) != -1)
				{
					// Origin is already setup!  Nothing to do.
				}
				else
				{
					// No origin is set, so let's add it!
					RunGit("remote add origin " + GitRepositoryURL);
				}
			}

			// Fetch all of the remote branches/tags into our local index.  This is needed so that we can figure out
			// which branches exist already.
			RunGit("fetch");
		}

		for (int PR = PRMin; PR <= PRMax; PR++)
		{
			try
			{
				ExecuteInner(Dir, PR);
			}
			catch (Exception Ex)
			{
				LogInformation(" Exception was {0}", LogUtils.FormatException(Ex));
				Failures.Add(String.Format("PR {0} Failed with {1}", PR, LogUtils.FormatException(Ex)));
			}
		}
		PopDir();

		foreach (var Failed in Failures)
		{
			LogInformation("{0}", Failed);
		}
	}
}

[Help("Throws an automation exception.")]
class TestFail : BuildCommand
{
	public override void ExecuteBuild()
	{
		throw new AutomationException("TestFail throwing an exception, cause that is what I do.");
	}
}

[Help("Prints a message and returns success.")]
class TestSuccess : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("TestSuccess message.");
	}
}

[Help("Prints a message and returns success.")]
class TestMessage : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("TestMessage message.");
		LogInformation("you must be in error");
		LogInformation("Behold the Error of you ways");
		LogInformation("ERROR, you are silly");
		LogInformation("ERROR: Something must be broken");
	}
}

[Help("Calls UAT recursively with a given command line.")]
class TestRecursion : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("TestRecursion *********************");
		string Params = ParseParamValue("Cmd");
		LogInformation("Recursive Command: {0}", Params);
		RunUAT(CmdEnv, Params, "Recur");

	}
}
[Help("Calls UAT recursively with a given command line.")]
class TestRecursionAuto : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("TestRecursionAuto *********************");
		RunUAT(CmdEnv, "TestMessage", "TestMessage");
		RunUAT(CmdEnv, "TestMessage", "TestMessage");
		RunUAT(CmdEnv, "TestRecursion -Cmd=TestMessage", "TestRecursion");
		RunUAT(CmdEnv, "TestRecursion -Cmd=TestFail", "TestRecursion");

	}
}

[Help("Makes a zip file in Rocket/QFE")]
class TestMacZip : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("TestMacZip *********************");

		if (UnrealBuildTool.Utils.IsRunningOnMono)
		{
			PushDir(CombinePaths(CmdEnv.LocalRoot, "Rocket/QFE"));
			RunAndLog(CommandUtils.CmdEnv, "zip", "-r TestZip .");
			PopDir();
		}
		else
		{
			throw new AutomationException("This probably only works on the mac.");
		}
	}
}

[Help("Tests P4 functionality. Creates a new changelist under the workspace %P4CLIENT%")]
[RequireP4]
class TestP4_CreateChangelist : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("P4CLIENT={0}", GetEnvVar("P4CLIENT"));
		LogInformation("P4PORT={0}", GetEnvVar("P4PORT"));

		var CLDescription = "AutomationTool TestP4";

		LogInformation("Creating new changelist \"{0}\" using client \"{1}\"", CLDescription, GetEnvVar("P4CLIENT"));
		var ChangelistNumber = P4.CreateChange(Description: CLDescription);
		LogInformation("Created changelist {0}", ChangelistNumber);
	}
}

[RequireP4]
class TestP4_StrandCheckout : BuildCommand
{
	public override void ExecuteBuild()
	{
		int WorkingCL = P4.CreateChange(P4Env.Client, String.Format("TestP4_StrandCheckout, head={0}", P4Env.Changelist));

		LogInformation("Build from {0}    Working in {1}", P4Env.Changelist, WorkingCL);

		List<string> Sign = new List<string>();
		Sign.Add(CombinePaths(CmdEnv.LocalRoot, @"\Engine\Binaries\DotNET\AgentInterface.dll"));

		LogInformation("Signing and adding {0} build products to changelist {1}...", Sign.Count, WorkingCL);

		CodeSign.SignMultipleIfEXEOrDLL(this, Sign);
		foreach (var File in Sign)
		{
			P4.Sync("-f -k " + File + "#head"); // sync the file without overwriting local one
			if (!FileExists(File))
			{
				throw new AutomationException("BUILD FAILED {0} was a build product but no longer exists", File);
			}

			P4.ReconcileNoDeletes(WorkingCL, File);
		}
	}
}

[RequireP4]
class TestP4_LabelDescription : BuildCommand
{
	public override void ExecuteBuild()
	{
		string Label = GetEnvVar("SBF_LabelFromUser");
		string Desc;
		LogInformation("LabelDescription {0}", Label);
		var Result = P4.LabelDescription(Label, out Desc);
		if (!Result)
		{
			throw new AutomationException("Could not get label description");
		}
		LogInformation("Result***\n{0}\n***\n", Desc);
	}
}

[RequireP4]
class TestP4_ClientOps : BuildCommand
{
	public override void ExecuteBuild()
	{
		string TemplateClient = "ue4_licensee_workspace";
		var Clients = P4.GetClientsForUser("UE4_Licensee");

		string TestClient = "UAT_Test_Client";

		P4ClientInfo NewClient = null;
		foreach (var Client in Clients)
		{
			if (Client.Name == TemplateClient)
			{
				NewClient = Client;
				break;
			}
		}
		if (NewClient == null)
		{
			throw new AutomationException("Could not find template");
		}
		NewClient.Owner = P4Env.User; // this is not right, we need the actual licensee user!
		NewClient.Host = Environment.MachineName.ToLower();
		NewClient.RootPath = @"C:\TestClient";
		NewClient.Name = TestClient;
		if (P4.DoesClientExist(TestClient))
		{
			P4.DeleteClient(TestClient);
		}
		P4.CreateClient(NewClient);

		//P4CLIENT         Name of client workspace        p4 help client
		//P4PASSWD         User password passed to server  p4 help passwd

		string[] VarsToSave = 
        {
            "P4CLIENT",
            //"P4PASSWD",

        };
		var KeyValues = new Dictionary<string, string>();
		foreach (var ToSave in VarsToSave)
		{
			KeyValues.Add(ToSave, GetEnvVar(ToSave));
		}

		SetEnvVar("P4CLIENT", NewClient.Name);
		//SetEnv("P4PASSWD", ParseParamValue("LicenseePassword");


		//Sync(CombinePaths(PathSeparator.Slash, P4Env.BuildRootP4, "UE4Games.uprojectdirs"));
		string Output;
		P4.P4Output(out Output, "files -m 10 " + CombinePaths(PathSeparator.Slash, P4Env.Branch, "..."));

		var Lines = Output.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
		string SlashRoot = CombinePaths(PathSeparator.Slash, P4Env.Branch, "/");
		string LocalRoot = CombinePaths(CmdEnv.LocalRoot, @"\");
		foreach (string Line in Lines)
		{
			if (Line.Contains(" - ") && Line.Contains("#"))
			{
				string depot = Line.Substring(0, Line.IndexOf("#"));
				if (!depot.Contains(SlashRoot))
				{
					throw new AutomationException("{0} does not contain {1} and it is supposed to.", depot, P4Env.Branch);
				}
				string local = CombinePaths(depot.Replace(SlashRoot, LocalRoot));
				LogInformation("{0}", depot);
				LogInformation("    {0}", local);
			}
		}

		// should be used as a sanity check! make sure there are no files!
		P4.LogP4Output(out Output, "files -m 10 " + CombinePaths(PathSeparator.Slash, P4Env.Branch, "...", "NoRedist", "..."));

		// caution this doesn't actually use the client _view_ from the template at all!
		// if you want that sync -f -k /...
		// then use client syntax in the files command instead
		// don't think we care, we don't rely on licensee _views_

		foreach (var ToLoad in VarsToSave)
		{
			SetEnvVar(ToLoad, KeyValues[ToLoad]);
		}
		P4.DeleteClient(TestClient);
	}
}


class CleanDDC : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("*********************** Clean DDC");

		bool DoIt = ParseParam("DoIt");

		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				for (int k = 0; k < 10; k++)
				{
					string Dir = CombinePaths(String.Format(@"P:\UE4DDC\{0}\{1}\{2}", i, j, k));
					if (!DirectoryExists_NoExceptions(Dir))
					{
						throw new AutomationException("Missing DDC dir {0}", Dir);
					}
					var files = FindFiles_NoExceptions("*.*", false, Dir);
					foreach (var file in files)
					{
						if (FileExists_NoExceptions(file))
						{
							FileInfo Info = new FileInfo(file);
							LogInformation("{0}", file);
							if ((DateTime.UtcNow - Info.LastWriteTimeUtc).TotalDays > 20)
							{
								LogInformation("  is old.");
								if (DoIt)
								{
									DeleteFile_NoExceptions(file);
								}
							}
							else
							{
								LogInformation("  is NOT old.");
							}
						}
					}
				}
			}
		}
	}

}

class TestTestFarm : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("*********************** TestTestFarm");

		string Exe = CombinePaths(CmdEnv.LocalRoot, "Engine", "Binaries", "Win64", "UE4Editor.exe");
		string ClientLogFile = CombinePaths(CmdEnv.LogFolder, "HoverGameRun");
		string CmdLine = " ../../../Samples/HoverShip/HoverShip.uproject -game -log -abslog=" + ClientLogFile;

		IProcessResult App = Run(Exe, CmdLine, null, ERunOptions.AllowSpew | ERunOptions.NoWaitForExit | ERunOptions.AppMustExist | ERunOptions.NoStdOutRedirect);

		LogFileReaderProcess(ClientLogFile, App, (string Output) =>
		{
			if (!String.IsNullOrEmpty(Output) &&
					Output.Contains("Game Engine Initialized"))
			{
				LogInformation("It looks started, let me kill it....");
				App.StopProcess();
			}
			return true; //keep reading
		});
	}
}

[Help("Test command line argument parsing functions.")]
class TestArguments : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("List of provided arguments: ");
		for (int Index = 0; Index < Params.Length; ++Index)
		{
			LogInformation("{0}={1}", Index, Params[Index].ToString());
		}

		string[] TestArgs = new string[] { "NoXGE", "SomeArg", "Map=AwesomeMap", "run=whatever", "Stuff" };

		if (!ParseParam(TestArgs, "noxge"))
		{
			throw new AutomationException("ParseParam test failed.");
		}

		if (ParseParam(TestArgs, "Dude"))
		{
			throw new AutomationException("ParseParam test failed.");
		}

		if (!ParseParam(TestArgs, "Stuff"))
		{
			throw new AutomationException("ParseParam test failed.");
		}

		string Val = ParseParamValue(TestArgs, "map");
		if (Val != "AwesomeMap")
		{
			throw new AutomationException("ParseParamValue test failed.");
		}

		Val = ParseParamValue(TestArgs, "run");
		if (Val != "whatever")
		{
			throw new AutomationException("ParseParamValue test failed.");
		}
	}
}

[Help("Checks if combine paths works as excpected")]
public class TestCombinePaths : BuildCommand
{
	public override void ExecuteBuild()
	{
		var Results = new string[]
		{
			CombinePaths("This/", "Is", "A", "Test"),
			CombinePaths("This", "Is", "A", "Test"),
			CombinePaths("This/", @"Is\A", "Test"),
			CombinePaths(@"This\Is", @"A\Test"),
			CombinePaths(@"This\Is\A\Test"),
			CombinePaths("This/", @"Is\", "A", null, "Test", String.Empty),
			CombinePaths(null, "This/", "Is", @"A\", "Test")
		};

		for (int Index = 0; Index < Results.Length; ++Index)
		{
			var CombinedPath = Results[Index];
			LogInformation(CombinedPath);
			if (CombinedPath != Results[0])
			{
				throw new AutomationException("Path {0} does not match path 0: {1} (expected: {2})", Index, CombinedPath, Results[0]);
			}
		}
	}
}

[Help("Tests file utility functions.")]
[Help("file=Filename", "Filename to perform the tests on.")]
class TestFileUtility : BuildCommand
{
	public override void ExecuteBuild()
	{
		string DummyFilename = ParseParamValue("file", "");
		DeleteFile(DummyFilename);
	}
}

class TestLog : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("************************* ShooterGameRun");
		string MapToRun = ParseParamValue("map", "/game/maps/sanctuary");

		PushDir(CombinePaths(CmdEnv.LocalRoot, @"Engine/Binaries/Win64/"));
		//		string GameServerExe = CombinePaths(CmdEnv.LocalRoot, @"ShooterGame/Binaries/Win64/ShooterGameServer.exe");
		//		string GameExe = CombinePaths(CmdEnv.LocalRoot, @"ShooterGame/Binaries/Win64/ShooterGame.exe");
		string EditorExe = CombinePaths(CmdEnv.LocalRoot, @"Engine/Binaries/Win64/UE4Editor.exe");

		string ServerLogFile = CombinePaths(CmdEnv.LogFolder, "Server.log");

		string ServerApp = EditorExe;
		string OtherArgs = String.Format("{0} -server -abslog={1} -log", MapToRun, ServerLogFile);
		string StartArgs = "ShooterGame ";

		string ServerCmdLine = StartArgs + OtherArgs;

		IProcessResult ServerProcess = Run(ServerApp, ServerCmdLine, null, ERunOptions.AllowSpew | ERunOptions.NoWaitForExit | ERunOptions.AppMustExist | ERunOptions.NoStdOutRedirect);

		LogFileReaderProcess(ServerLogFile, ServerProcess, (string Output) =>
		{
			if (String.IsNullOrEmpty(Output) == false)
			{
				Console.Write(Output);
			}
			return true; // keep reading
		});
	}
}

[Help("Tests P4 change filetype functionality.")]
[Help("File", "Binary file to change the filetype to writeable")]
[RequireP4]
class TestChangeFileType : BuildCommand
{
	public override void ExecuteBuild()
	{
		var Filename = ParseParamValue("File", "");
		if (P4.FStat(Filename).Type == P4FileType.Binary)
		{
			P4.ChangeFileType(Filename, P4FileAttributes.Writeable);
		}
	}
}

public sealed class SafeTokenHandle : SafeHandleZeroOrMinusOneIsInvalid
{
	private SafeTokenHandle()
		: base(true)
	{

	}

	[DllImport("kernel32.dll")]
	[ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
	[SuppressUnmanagedCodeSecurity]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool CloseHandle(IntPtr Handle);

	protected override bool ReleaseHandle()
	{
		return CloseHandle(handle);
	}
}

[Help("Tests if UE4Build properly copies all relevent UAT build products to the Binaries folder.")]
public class TestUATBuildProducts : BuildCommand
{
	public override void ExecuteBuild()
	{
		UE4Build Build = new UE4Build(this);
		Build.AddUATFilesToBuildProducts();

		LogInformation("Build products:");
		foreach (var Product in Build.BuildProductFiles)
		{
			LogInformation("  " + Product);
		}
	}
}



class TestOSSCommands : BuildCommand
{
	public override void ExecuteBuild()
	{
		string Exe = CombinePaths(CmdEnv.LocalRoot, "Engine", "Binaries", "Win64", "UE4Editor.exe");
		string CmdLine = "qagame automation-osscommands -game -log -logcmds=" + "\"" + "global none, logonline verbose, loghttp log, LogBlueprintUserMessages log" + "\"";
		string ClientLogFile = CombinePaths(CmdEnv.LogFolder, String.Format("QALog_{0:yyyy-MM-dd_hh-mm-ss-tt}.txt", DateTime.Now));
		string LogDirectory = CombinePaths(CmdEnv.LocalRoot, "Saved", "Logs");

		if (!File.Exists(ClientLogFile))
		{
			File.Create(ClientLogFile).Close();
		}

		try
		{
			RunAndLog(Exe, CmdLine, ClientLogFile);
		}
		catch (Exception Err)
		{
			LogInformation(Err.Message);
		}

		FileInfo[] LogFiles = new DirectoryInfo(LogDirectory).GetFiles();
		FileInfo QALogFile = LogFiles[0];

		for (int i = 0; i < LogFiles.Length; i++)
		{
			if (LogFiles[i].LastWriteTime > QALogFile.LastWriteTime)
			{
				QALogFile = LogFiles[i];
			}
		}

		string[] Lines = File.ReadAllLines(QALogFile.FullName);

		StreamWriter WriteErrors = new StreamWriter(new FileStream(ClientLogFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite));

		/* 
         * online sub=amazon test friends - Warning: Failed to get friends interface for amazon
         * online sub=amazon test identity - Error: RegisterUser() : OnlineSubsystemAmazon is improperly configured in DefaultEngine.ini
         * ErrorCode 00002EE7 - http test <iterations> <url> - Desc: The server name or address could not be resolved
         * Error/code 404 - online sub=mcp test validateaccount <email> <validation code> - Warning: MCP: Mcp validate Epic account request failed. Invalid response. Not found.
         * Error/code 404 - online sub=mcp test deleteaccount <email> <password> - Warning: MCP: Mcp delete Epic account request failed. Not found.
         * online sub=mcp test friends - Warning: Failed to get friends interface for mcp
         * bSucess: 0 - online sub=mcp test sessionhost - LogOnline:Verbose: OnCreateSessionComplete Game bSuccess: 0
         * Code 401 - online sub=mcp test time - Failed to query server time
         * Error code 500 - online sub=mcp test entitlements - profile template not found
        */

		using (WriteErrors)
		{
			for (int i = 0; i < Lines.Length; i++)
			{
				if (Lines[i].Contains("error=404") || Lines[i].Contains("code=404"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
				else if (Lines[i].Contains("code=401"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
				else if (Lines[i].Contains("error=500"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
				else if (Lines[i].Contains("bSucess: 0"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
				else if (Lines[i].Contains("Warning: Failed to get friends interface"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
				else if (Lines[i].Contains("Error: RegisterUser() : OnlineSubsystemAmazon is improperly configured"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
				else if (Lines[i].Contains("ErrorCode 00002EE7"))
				{
					WriteErrors.WriteLine(Lines[i]);
				}
			}
		}

	}
}

[Help("Builds a project using UBT. Syntax is similar to UBT with the exception of '-', i.e. UBT -QAGame -Development -Win32")]
[Help("NoXGE", "Disable XGE")]
[Help("Clean", "Clean build products before building")]
public class UBT : BuildCommand
{
	public override void ExecuteBuild()
	{
		var Build = new UE4Build(this);
		var Agenda = new UE4Build.BuildAgenda();
		var Platform = UnrealBuildTool.UnrealTargetPlatform.Win64;
		var Configuration = UnrealBuildTool.UnrealTargetConfiguration.Development;
		var Targets = new List<string>();

		foreach (var ObjParam in Params)
		{
			var Param = (string)ObjParam;
			if (!UnrealTargetPlatform.TryParse(Param, out Platform))
			{
				continue;
			}
			UnrealBuildTool.UnrealTargetConfiguration ParseConfiguration;
			if (Enum.TryParse<UnrealBuildTool.UnrealTargetConfiguration>(Param, true, out ParseConfiguration))
			{
				Configuration = ParseConfiguration;
				continue;
			}
			if (String.Compare("NoXGE", Param, true) != 0 && String.Compare("Clean", Param, true) != 0)
			{
				Targets.Add(Param);
			}
		}

		var Clean = ParseParam("Clean");

		Agenda.AddTargets(Targets.ToArray(), Platform, Configuration);

		LogInformation("UBT Buid");
		LogInformation("Targets={0}", String.Join(",", Targets));
		LogInformation("Platform={0}", Platform);
		LogInformation("Configuration={0}", Configuration);
		LogInformation("Clean={0}", Clean);

		Build.Build(Agenda, InUpdateVersionFiles: false);

		LogInformation("UBT Completed");
	}
}

[Help("Helper command to sync only source code + engine files from P4.")]
[Help("Branch", "Optional branch depot path, default is: -Branch=//depot/UE4")]
[Help("CL", "Optional changelist to sync (default is latest), -CL=1234567")]
[Help("Sync", "Optional list of branch subforlders to always sync separated with '+', default is: -Sync=Engine/Binaries/ThirdParty+Engine/Content")]
[Help("Exclude", "Optional list of folder names to exclude from syncing, separated with '+', default is: -Exclude=Binaries+Content+Documentation+DataTables")]
[RequireP4]
public class SyncSource : BuildCommand
{
	private void SafeSync(string SyncCmdLine)
	{
		try
		{
			P4.Sync(SyncCmdLine);
		}
		catch (Exception Ex)
		{
			LogError("Unable to sync {0}", SyncCmdLine);
			LogError(Ex.Message);
		}
	}

	public override void ExecuteBuild()
	{
		var Changelist = ParseParamValue("cl", "");
		if (!String.IsNullOrEmpty(Changelist))
		{
			Changelist = "@" + Changelist;
		}

		var AlwaysSync = new List<string>(new string[]
			{
				"Engine/Binaries/ThirdParty",
				"Engine/Content",
			}
		);
		var AdditionalAlwaysSyncPaths = ParseParamValue("sync");
		if (!String.IsNullOrEmpty(AdditionalAlwaysSyncPaths))
		{
			var AdditionalPaths = AdditionalAlwaysSyncPaths.Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries);
			AlwaysSync.AddRange(AdditionalPaths);
		}

		var ExclusionList = new HashSet<string>(new string[]
			{
				"Binaries",
				"Content",
				"Documentation",
				"DataTables",
			},
			StringComparer.InvariantCultureIgnoreCase
		);
		var AdditionalExlusionPaths = ParseParamValue("exclude");
		if (!String.IsNullOrEmpty(AdditionalExlusionPaths))
		{
			var AdditionalPaths = AdditionalExlusionPaths.Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries);
			foreach (var Dir in AdditionalPaths)
			{
				ExclusionList.Add(Dir);
			}
		}

		var DepotPath = ParseParamValue("branch", "//depot/UE4/");
		foreach (var AlwaysSyncSubFolder in AlwaysSync)
		{
			var SyncCmdLine = CombinePaths(PathSeparator.Depot, DepotPath, AlwaysSyncSubFolder, "...") + Changelist;
			LogInformation("Syncing {0}", SyncCmdLine, Changelist);
			SafeSync(SyncCmdLine);
		}

		DepotPath = CombinePaths(PathSeparator.Depot, DepotPath, "*");
		var ProjectDirectories = P4.Dirs(String.Format("-D {0}", DepotPath));
		foreach (var ProjectDir in ProjectDirectories)
		{
			var ProjectDirPath = CombinePaths(PathSeparator.Depot, ProjectDir, "*");
			var SubDirectories = P4.Dirs(ProjectDirPath);
			foreach (var SubDir in SubDirectories)
			{
				var SubDirName = Path.GetFileNameWithoutExtension(GetDirectoryName(SubDir));
				if (!ExclusionList.Contains(SubDirName))
				{
					var SyncCmdLine = CombinePaths(PathSeparator.Depot, SubDir, "...") + Changelist;
					LogInformation("Syncing {0}", SyncCmdLine);
					SafeSync(SyncCmdLine);
				}
			}
		}
	}
}

[Help("Generates automation project based on a template.")]
[Help("project=ShortName", "Short name of the project, i.e. QAGame")]
[Help("path=FullPath", "Absolute path to the project root directory, i.e. C:\\UE4\\QAGame")]
public class GenerateAutomationProject : BuildCommand
{
	public override void ExecuteBuild()
	{
		var ProjectName = ParseParamValue("project");
		var ProjectPath = ParseParamValue("path");

		{
			var CSProjFileTemplate = ReadAllText(CombinePaths(CmdEnv.LocalRoot, "Engine", "Extras", "UnsupportedTools", "AutomationTemplate", "AutomationTemplate.Automation.xml"));
			StringBuilder CSProjBuilder = new StringBuilder(CSProjFileTemplate);
			CSProjBuilder.Replace("AutomationTemplate", ProjectName);

			{
				const string ProjectGuidTag = "<ProjectGuid>";
				int ProjectGuidStart = CSProjFileTemplate.IndexOf(ProjectGuidTag) + ProjectGuidTag.Length;
				int ProjectGuidEnd = CSProjFileTemplate.IndexOf("</ProjectGuid>", ProjectGuidStart);
				string OldProjectGuid = CSProjFileTemplate.Substring(ProjectGuidStart, ProjectGuidEnd - ProjectGuidStart);
				string NewProjectGuid = Guid.NewGuid().ToString("B");
				CSProjBuilder.Replace(OldProjectGuid, NewProjectGuid);
			}

			{
				const string OutputPathTag = "<OutputPath>";
				var OutputPath = CombinePaths(CmdEnv.LocalRoot, "Engine", "Binaries", "DotNET", "AutomationScripts");
				int PathStart = CSProjFileTemplate.IndexOf(OutputPathTag) + OutputPathTag.Length;
				int PathEnd = CSProjFileTemplate.IndexOf("</OutputPath>", PathStart);
				string OldOutputPath = CSProjFileTemplate.Substring(PathStart, PathEnd - PathStart);
				string NewOutputPath = ConvertSeparators(PathSeparator.Slash, UnrealBuildTool.Utils.MakePathRelativeTo(OutputPath, ProjectPath)) + "/";
				CSProjBuilder.Replace(OldOutputPath, NewOutputPath);
			}

			if (!DirectoryExists(ProjectPath))
			{
				CreateDirectory(ProjectPath);
			}
			WriteAllText(CombinePaths(ProjectPath, ProjectName + ".Automation.csproj"), CSProjBuilder.ToString());
		}

		{
			var PropertiesFileTemplate = ReadAllText(CombinePaths(CmdEnv.LocalRoot, "Engine", "Extras", "UnsupportedTools", "AutomationTemplate", "Properties", "AssemblyInfo.cs"));
			StringBuilder PropertiesBuilder = new StringBuilder(PropertiesFileTemplate);
			PropertiesBuilder.Replace("AutomationTemplate", ProjectName);

			const string AssemblyGuidTag = "[assembly: Guid(\"";
			int AssemblyGuidStart = PropertiesFileTemplate.IndexOf(AssemblyGuidTag) + AssemblyGuidTag.Length;
			int AssemblyGuidEnd = PropertiesFileTemplate.IndexOf("\")]", AssemblyGuidStart);
			string OldAssemblyGuid = PropertiesFileTemplate.Substring(AssemblyGuidStart, AssemblyGuidEnd - AssemblyGuidStart);
			string NewAssemblyGuid = Guid.NewGuid().ToString("D");
			PropertiesBuilder.Replace(OldAssemblyGuid, NewAssemblyGuid);

			string PropertiesPath = CombinePaths(ProjectPath, "Properties");
			if (!DirectoryExists(PropertiesPath))
			{
				CreateDirectory(PropertiesPath);
			}
			WriteAllText(CombinePaths(PropertiesPath, "AssemblyInfo.cs"), PropertiesBuilder.ToString());
		}

	}
}

class DumpBranch : BuildCommand
{

	public override void ExecuteBuild()
	{
		LogInformation("************************* DumpBranch");

		new BranchInfo();
	}
}

[Help("Sleeps for 20 seconds and then exits")]
public class DebugSleep : BuildCommand
{
	public override void ExecuteBuild()
	{
		Thread.Sleep(20000);
	}
}

[Help("Tests if Mcp configs loaded properly.")]
class TestMcpConfigs : BuildCommand
{
	public override void ExecuteBuild()
	{
		EpicGames.MCP.Config.McpConfigHelper.Find("localhost");
	}
}



[Help("Test Blame P4 command.")]
[Help("File", "(Optional) Filename of the file to produce a blame output for")]
[Help("Out", "(Optional) File to save the blame result to.")]
[Help("Timelapse", "If specified, will use Timelapse command instead of Blame")]
[RequireP4]
class TestBlame : BuildCommand
{
	public override void ExecuteBuild()
	{
		var Filename = ParseParamValue("File", "//depot/UE4/Engine/Source/Runtime/PakFile/Public/IPlatformFilePak.h");
		var OutFilename = ParseParamValue("Out");

		LogInformation("Creating blame file for {0}", Filename);
		P4Connection.BlameLineInfo[] Result = null;
		if (ParseParam("Timelapse"))
		{
			Result = P4.Timelapse(Filename);
		}
		else
		{
			Result = P4.Blame(Filename);
		}
		var BlameResult = new StringBuilder();
		foreach (var BlameLine in Result)
		{
			var ResultLine = String.Format("#{0} in {1} by {2}: {3}", BlameLine.Revision.Revision, BlameLine.Revision.Changelist, BlameLine.Revision.User, BlameLine.Line);
			LogInformation(ResultLine);
			BlameResult.AppendLine(ResultLine);
		}
		if (String.IsNullOrEmpty(OutFilename) == false)
		{
			WriteAllText(OutFilename, BlameResult.ToString());
		}
	}
}

[Help("Test P4 changes.")]
[RequireP4]
[DoesNotNeedP4CL]
class TestChanges : BuildCommand
{
	public override void ExecuteBuild()
	{
		var CommandParam = ParseParamValue("CommandParam", "//depot/UE4-LauncherReleases/*/Source/...@2091742,2091950 //depot/UE4-LauncherReleases/*/Build/...@2091742,2091950");

		{
			List<P4Connection.ChangeRecord> ChangeRecords;
			if (!P4.Changes(out ChangeRecords, CommandParam, true, true, LongComment: true))
			{
				throw new AutomationException("failed");
			}
			foreach (var Record in ChangeRecords)
			{
				LogInformation("{0} {1} {2}", Record.CL, Record.UserEmail, Record.Summary);
			}
		}
		{
			List<P4Connection.ChangeRecord> ChangeRecords;
			if (!P4.Changes(out ChangeRecords, "-L " + CommandParam, true, true, LongComment: false))
			{
				throw new AutomationException("failed");
			}
			foreach (var Record in ChangeRecords)
			{
				LogInformation("{0} {1} {2}", Record.CL, Record.UserEmail, Record.Summary);
			}
		}
	}
}

[Help("Spawns a process to test if UAT kills it automatically.")]
class TestKillAll : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("*********************** TestKillAll");

		string Exe = CombinePaths(CmdEnv.LocalRoot, "Engine", "Binaries", "Win64", "UE4Editor.exe");
		string ClientLogFile = CombinePaths(CmdEnv.LogFolder, "HoverGameRun");
		string CmdLine = " ../../../Samples/Sandbox/HoverShip/HoverShip.uproject -game -log -abslog=" + ClientLogFile;

		Run(Exe, CmdLine, null, ERunOptions.AllowSpew | ERunOptions.NoWaitForExit | ERunOptions.AppMustExist | ERunOptions.NoStdOutRedirect);
		Thread.Sleep(10000);
	}
}

[Help("Tests CleanFormalBuilds.")]
class TestCleanFormalBuilds : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("*********************** TestCleanFormalBuilds");
		var Dir = ParseParamValue("Dir", @"P:\Builds\UE4\PackagedBuilds\++UE4+Release-4.11");
		CleanFormalBuilds(Dir, "CL-*");
	}
}


[Help("Spawns a process to test if it can be killed.")]
class TestStopProcess : BuildCommand
{
	public override void ExecuteBuild()
	{
		LogInformation("*********************** TestStopProcess");

		string Exe = CombinePaths(CmdEnv.LocalRoot, "Engine", "Binaries", "Win64", "UE4Editor.exe");
		string ClientLogFile = CombinePaths(CmdEnv.LogFolder, "HoverGameRun");
		string CmdLine = " ../../../Samples/Sandbox/HoverShip/HoverShip.uproject -game -log -ddc=noshared -abslog=" + ClientLogFile;

		for (int Attempt = 0; Attempt < 5; ++Attempt)
		{
			LogInformation("Attempt: {0}", Attempt);
			var Proc = Run(Exe, CmdLine, null, ERunOptions.AllowSpew | ERunOptions.NoWaitForExit | ERunOptions.AppMustExist | ERunOptions.NoStdOutRedirect);
			Thread.Sleep(10000);
			Proc.StopProcess();
		}

		LogInformation("One final attempt to test KillAll");
		Run(Exe, CmdLine, null, ERunOptions.AllowSpew | ERunOptions.NoWaitForExit | ERunOptions.AppMustExist | ERunOptions.NoStdOutRedirect);
		Thread.Sleep(10000);
	}
}

[Help("Looks through an XGE xml for overlapping obj files")]
[Help("Source", "full path of xml to look at")]
class LookForOverlappingBuildProducts : BuildCommand
{
	public override void ExecuteBuild()
	{
		var SourcePath = ParseParamValue("Source=");
		if (String.IsNullOrEmpty(SourcePath))
		{
			SourcePath = "D:\\UAT_XGE.xml";
		}
		if (!FileExists_NoExceptions(SourcePath))
		{
			throw new AutomationException("Source path not found, please use -source=Path");
		}
		var Objs = new HashSet<string>( StringComparer.InvariantCultureIgnoreCase );
//    /Fo&quot;D:\BuildFarm\buildmachine_++depot+UE4\Engine\Intermediate\Build\Win64\UE4Editor\Development\Projects\Module.Projects.cpp.obj&quot;
		var FileText = ReadAllText(SourcePath);
		string Start = "/Fo&quot;";
		string End = "&quot;";
		while (true)
		{
			var Index = FileText.IndexOf(Start);
			if (Index >= 0)
			{
				FileText = FileText.Substring(Index + Start.Length);
				Index = FileText.IndexOf(End);
				if (Index >= 0)
				{
					var ObjFile = FileText.Substring(0, Index);
					if (Objs.Contains(ObjFile))
					{
						LogError("Duplicate obj: {0}", ObjFile);
					}
					else
					{
						Objs.Add(ObjFile);
					}
					FileText = FileText.Substring(Index + End.Length);
				}
				else
				{
					break;
				}
			}
			else
			{
				break;
			}
		}
	}
}

[Help("Copies all files from source directory to destination directory using ThreadedCopyFiles")]
[Help("Source", "Source path")]
[Help("Dest", "Destination path")]
[Help("Threads", "Number of threads used to copy files (64 by default)")]
class TestThreadedCopyFiles : BuildCommand
{
	public override void ExecuteBuild()
	{
		var SourcePath = ParseParamValue("Source=");
		var DestPath = ParseParamValue("Dest=");
		var Threads = ParseParamInt("Threads=", 64);

		if (String.IsNullOrEmpty(SourcePath))
		{
			throw new AutomationException("Source path not specified, please use -source=Path");
		}
		if (String.IsNullOrEmpty(DestPath))
		{
			throw new AutomationException("Destination path not specified, please use -dest=Path");
		}
		if (!DirectoryExists(SourcePath))
		{
			throw new AutomationException("Source path {0} does not exist", SourcePath);
		}

		DeleteDirectory(DestPath);

		using (var ScopedCopyTimer = new ScopedTimer("ThreadedCopyFiles"))
		{
			ThreadedCopyFiles(SourcePath, DestPath, Threads);
		}
	}
}
