// Copyright Epic Games, Inc. All Rights Reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using AutomationTool;

class BuildPatchToolBuild : BuildCommand
{
	#region Fields
	#endregion

	public override void ExecuteBuild()
	{
	}
}
