// Copyright Epic Games, Inc. All Rights Reserved.

#include "AndroidMediaSettings.h"


/* UAndroidMediaSettings structors
 *****************************************************************************/

UAndroidMediaSettings::UAndroidMediaSettings()
	: CacheableVideoSampleBuffers(false)
{ }
