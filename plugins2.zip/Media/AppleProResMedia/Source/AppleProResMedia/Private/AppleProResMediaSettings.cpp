// Copyright Epic Games, Inc. All Rights Reserved.

#include "AppleProResMediaSettings.h"

UAppleProResMediaSettings::UAppleProResMediaSettings()
	: NumberOfCPUDecodingThreads(0)
{ 
}
