// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

namespace Electra {

	class IVideoDecoderResourceDelegate
	{
	public:
		virtual ~IVideoDecoderResourceDelegate() {}
	};

}
