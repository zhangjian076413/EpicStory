// Copyright Epic Games, Inc. All Rights Reserved.

#include "AndroidCameraSettings.h"


/* UAndroidMediaSettings structors
 *****************************************************************************/

UAndroidCameraSettings::UAndroidCameraSettings()
	: CacheableVideoSampleBuffers(false)
{ }
