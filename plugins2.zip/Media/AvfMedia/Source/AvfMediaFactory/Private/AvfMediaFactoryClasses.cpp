// Copyright Epic Games, Inc. All Rights Reserved.

#include "AvfMediaSettings.h"


UAvfMediaSettings::UAvfMediaSettings()
	: NativeAudioOut(false)
{ }
